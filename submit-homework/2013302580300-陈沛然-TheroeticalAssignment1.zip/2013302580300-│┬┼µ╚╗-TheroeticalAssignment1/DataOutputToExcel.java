/*
 * ��html�ı���������ݳ�ȡ��������excel��
*/

package cn;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.safety.Whitelist;
import org.jsoup.select.Elements;

public class DataOutputToExcel {

	public void outputToExcel() throws IOException, WriteException {

		File file = new File("hello.html");
		Document doc = Jsoup.parse(file, "GBK");
		Elements trs = doc.getElementsByTag("tr");
		Element ths = trs.get(0);
		String th = Jsoup.clean(ths.toString(), Whitelist.none());

		FileOutputStream fOut = new FileOutputStream("score.xls");
		WritableWorkbook workbook = Workbook.createWorkbook(fOut);
		WritableSheet sheet = workbook.createSheet("�ɼ�", 0);
		sheet.setColumnView(0, 20); // �����еĿ���
		sheet.setColumnView(1, 30);
		sheet.setColumnView(5, 16);
		
		String[] strTh = th.split("[\\p{Space}]+");
		for (int i = 0; i < strTh.length; i++) {//�����ͷ

			Label cellTh = new Label(i, 0, strTh[i]);
			sheet.addCell(cellTh);
		}

		for (int x = 1; x < trs.size(); x++) {//��������

			Elements td = trs.get(x).getElementsByTag("td");
			String str = td.toString();
			String goals = Jsoup.clean(str, Whitelist.none());
			String[] strTd = goals.split("[\\p{Space}]+");

			for (int y = 0; y < strTd.length; y++) {

				Label cellTd = new Label(y, x, strTd[y]);
				sheet.addCell(cellTd);
			}

		}

		workbook.write();
		workbook.close();
		fOut.close();
	}

	public static void main(String[] args) throws IOException, WriteException {

		DataOutputToExcel d = new DataOutputToExcel();
		d.outputToExcel();

	}

}
