/*
 * ��html�ı���������ݳ�ȡ��������txt�ļ���
*/
package cn;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.safety.Whitelist;
import org.jsoup.select.Elements;

public class DataOutputToTxt {

	public void outputDatas() throws IOException {

		File file = new File("hello.html");
		Document doc = Jsoup.parse(file, "GBK");
		Elements trs = doc.getElementsByTag("tr");
		Element ths = trs.get(0);
		String th = Jsoup.clean(ths.toString(), Whitelist.none());
		PrintWriter pw = new PrintWriter(new FileWriter("score.txt"));
		pw.println(th);

		for (int i = 1; i < trs.size(); i++) {

			Elements td = trs.get(i).getElementsByTag("td");
			String str = td.toString();
			String goals = Jsoup.clean(str, Whitelist.none());
			pw.println(goals);
		}
		pw.close();
		
	}

	public static void main(String[] args) throws IOException {

		DataOutputToTxt d = new DataOutputToTxt();
		d.outputDatas();

	}
}
